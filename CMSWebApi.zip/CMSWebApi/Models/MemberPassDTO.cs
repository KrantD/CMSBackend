﻿namespace CMSWebApi.Models
{
    public class MemberPassDTO:Member
    {
        public string? Password { get; set; }
    }
}
